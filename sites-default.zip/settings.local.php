<?php

$databases['default']['default'] = array(
  'driver' => 'mysql',
  'database' => 'local',
  'username' => 'drupal',
  'password' => 'drupal',
  'host' => '127.0.0.1',
);

ini_set('memory_limit', '1024M');

$config['search_api.server.solr']['backend_config']['connector_config']['core'] = 'drupal';

$settings['container_yamls'][] = __DIR__ . '/local.service.yml';

if (!empty($_GET['verbose'])) {
  $config['system.logging']['error_level'] = 'verbose';
}

$settings['container_yamls'][] = DRUPAL_ROOT . '/sites/default/services.local.yml';

// comment these when doing site building.
$settings['cache']['bins']['render'] = 'cache.backend.null';
$settings['cache']['bins']['page'] = 'cache.backend.null';
$settings['cache']['bins']['dynamic_page_cache'] = 'cache.backend.null';
